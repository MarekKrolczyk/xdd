import { test as baseTest } from "@playwright/test";
import { HomePage } from "@_src/pages/home.page";


const pageObjectTest = baseTest.extend<{
  homePage: HomePage;


}>({
  homePage: async ({ page }, use) => use(new HomePage(page)),
});

export default pageObjectTest;
export const expect = pageObjectTest.expect