import test, { expect } from "@_src/fixtures/page-object.fixture";

test.beforeEach(async ({ homePage }) => {
  await homePage.goto();
});

test.describe("User can see home page", () => {
  test("User can see header title", async ({ homePage }) => {
    // Assert
    expect(homePage.headerTitle).toBeVisible();
  });

});
